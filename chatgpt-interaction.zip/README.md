# ChatGPT Interaction

To request a question to ChatGPT, following below stesp:
1. Write the question in `request.txt` 
2. Run `python ie_test.py`
3. The answer is saved in `output.txt`